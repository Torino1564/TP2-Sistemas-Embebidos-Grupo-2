pyuic6 -x "designer/MainWindow.ui" -o "src/ui/MainWindow.py"
echo "DONE"